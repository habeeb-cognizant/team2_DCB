function showToast(message, duration = 3000) {
  const toast = document.createElement('div');
  toast.className = 'toast';
  toast.innerText = message;

  document.body.appendChild(toast);

  setTimeout(() => toast.classList.add('show'), 100);
  setTimeout(() => {
    toast.classList.remove('show');
    setTimeout(() => document.body.removeChild(toast), 500);
  }, duration);
}

// LOGIN FORM
document.getElementById('loginForm')?.addEventListener('submit', function(e) {
  e.preventDefault();
  console.log("Login form submitted");

  const email = document.getElementById('email').value.trim();
  const password = document.getElementById('password').value.trim();

  if (!email || !password) {
    showToast("Please enter both email and password.");
    return;
  }

  const btn = this.querySelector('button[type="submit"]');
  btn.disabled = true;
  btn.innerHTML = '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Logging in...';

  // Simulate API delay
  setTimeout(() => {
    try {
      console.log("Redirecting to complaint-form.html");
      window.location.href = "complaint-form.html";
    } catch (err) {
      console.error("Redirection failed:", err);
    }
  }, 800);
});

// COMPLAINT FORM
document.getElementById('complaintForm')?.addEventListener('submit', function(e) {
  e.preventDefault();
  console.log("Complaint form submitted");

  const category = document.getElementById('category').value.trim();
  const description = document.getElementById('description').value.trim();

  if (!category || !description) {
    showToast("Please fill in all required fields.");
    return;
  }

  const btn = this.querySelector('button[type="submit"]');
  btn.disabled = true;
  btn.innerHTML = '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Submitting...';

  setTimeout(() => {
    console.log("Redirecting to status-tracking.html");
    window.location.href = "status-tracking.html";
  }, 800);
});
// Handle status tracking
document.getElementById('statusForm')?.addEventListener('submit', function(e) {
  e.preventDefault();
  const input = document.getElementById('complaintId').value.trim().toLowerCase();

  let result = '';
  if (input.includes('@')) {
    result = 'Your complaint is currently: <span class="badge bg-warning text-dark">Pending</span>';
  } else if (!isNaN(input)) {
    result = 'Your complaint is: <span class="badge bg-success">Resolved</span>';
  } else {
    result = '<span class="text-danger">No matching complaint found.</span>';
  }

  document.getElementById('statusResult').innerHTML = `<p>${result}</p>`;
}); 